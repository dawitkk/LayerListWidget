define({
  "showLegend": "Gösterimi göster",
  "controlPopupMenuTitle": "Katman içerik menüsünde gösterilecek eylemleri seçin.",
  "zoomto": "Yakınlaştır",
  "transparency": "Şeffaflık",
  "controlPopup": "Açılır pencereyi etkinleştir / devre dışı bırak",
  "moveUpAndDown": "Yukarı taşı / Aşağı taşı",
  "attributeTable": "Öznitelik Tablosunda Görüntüle",
  "url": "Açıklama / Öğe ayrıntılarını göster / indir",
  "layerSelectorTitle": "Listede gösterilecek katmanları seçin."
});