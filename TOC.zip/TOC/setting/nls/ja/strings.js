define({
  "showLegend": "凡例の表示",
  "controlPopupMenuTitle": "レイヤーのショートカット メニューに表示されるアクションを選択します。",
  "zoomto": "ズーム",
  "transparency": "透過表示",
  "controlPopup": "ポップアップの有効化/無効化",
  "moveUpAndDown": "上に移動/下に移動",
  "attributeTable": "属性テーブルの表示",
  "url": "説明/アイテムの詳細を表示/ダウンロード",
  "layerSelectorTitle": "リストに表示されるレイヤーを選択します。"
});