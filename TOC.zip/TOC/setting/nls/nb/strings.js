define({
  "showLegend": "Vis tegnforklaring",
  "controlPopupMenuTitle": "Velg hvilke handlinger som skal vises i kontekstmenyen for laget.",
  "zoomto": "Zoom til",
  "transparency": "Gjennomsiktighet",
  "controlPopup": "Aktiver/deaktiver popup",
  "moveUpAndDown": "Flytt opp / Flytt ned",
  "attributeTable": "Vis i attributtabell",
  "url": "Beskrivelse / Vis elementdetaljer / Last ned",
  "layerSelectorTitle": "Velg hvilke lag som skal vises i listen."
});