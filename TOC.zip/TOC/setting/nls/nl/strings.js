define({
  "showLegend": "Legenda weergeven",
  "controlPopupMenuTitle": "Kies welke acties worden weergegeven in het laagcontextmenu.",
  "zoomto": "Zoomen naar",
  "transparency": "Transparant",
  "controlPopup": "Pop-up inschakelen / uitschakelen",
  "moveUpAndDown": "Omhoog / omlaag",
  "attributeTable": "Bekijken in Attribuuttabel",
  "url": "Beschrijving / Itemdetails weergeven / Downloaden",
  "layerSelectorTitle": "Kies welke lagen worden aangegeven op de lijst."
});