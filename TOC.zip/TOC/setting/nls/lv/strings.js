define({
  "showLegend": "Rādīt leģendu",
  "controlPopupMenuTitle": "Izvēlieties, kuras darbības tiks rādītas slāņa konteksta izvēlnē.",
  "zoomto": "Pietuvināt",
  "transparency": "Caurspīdīgums",
  "controlPopup": "Aktivizēt/deaktivizēt uznirstošo logu",
  "moveUpAndDown": "Pārvietot uz augšu/uz leju",
  "attributeTable": "Skatīt atribūtu tabulā",
  "url": "Apraksts/Rādīt detalizētu vienības informāciju/Lejupielādēt",
  "layerSelectorTitle": "Izvēlieties, kuri slāņi tiks rādīti sarakstā."
});