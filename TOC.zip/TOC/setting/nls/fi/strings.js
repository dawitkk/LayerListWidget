define({
  "showLegend": "Näytä selite",
  "controlPopupMenuTitle": "Valitse, mitkä toiminnot näytetään karttatason kontekstivalikossa.",
  "zoomto": "Tarkenna kohteeseen",
  "transparency": "Transparency",
  "controlPopup": "Ota ponnahdusikkunat käyttöön tai poista ne käytöstä",
  "moveUpAndDown": "Siirrä ylös / Siirrä alas",
  "attributeTable": "Näytä ominaisuustaulukossa",
  "url": "Kuvaus / Näytä kohteen tiedot / Lataa",
  "layerSelectorTitle": "Valitse, mitkä karttatasot näytetään luettelossa."
});