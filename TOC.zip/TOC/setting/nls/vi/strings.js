define({
  "showLegend": "Hiện chú giải",
  "controlPopupMenuTitle": "Chọn tác vụ sẽ được hiển thị trên menu ngữ cảnh lớp.",
  "zoomto": "Phóng tới",
  "transparency": "Độ trong suốt",
  "controlPopup": "Bật / Tắt cửa sổ pop-up",
  "moveUpAndDown": "Di chuyển lên / Di chuyển xuống",
  "attributeTable": "Xem trong Bảng Thuộc tính",
  "url": "Thông tin mô tả / Hiện thông tin chi tiết mục / Tải về",
  "layerSelectorTitle": "Chọn lớp sẽ được hiển thị trên danh sách."
});