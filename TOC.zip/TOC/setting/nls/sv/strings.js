define({
  "showLegend": "Visa teckenförklaring",
  "controlPopupMenuTitle": "Välj vilka åtgärder som ska visas på lagrets snabbmeny.",
  "zoomto": "Zooma till",
  "transparency": "Transparens",
  "controlPopup": "Aktivera/inaktivera popupfönster",
  "moveUpAndDown": "Flytta uppåt/Flytta nedåt",
  "attributeTable": "Visa i attributtabell",
  "url": "Beskrivning/Visa objektinformation/Hämta",
  "layerSelectorTitle": "Välj vilka lager som ska visas i listan."
});