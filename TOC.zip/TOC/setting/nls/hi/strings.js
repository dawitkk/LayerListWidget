define({
  "showLegend": "लीजेंड दिखाएँ",
  "controlPopupMenuTitle": "उन क्रियाओं का चयन करें जो लेयर संदर्भ मेनू पर दिखाई जाएंगी।",
  "zoomto": "जूम करें",
  "transparency": "पारदर्शिता",
  "controlPopup": "पॉप-अप सक्षम/अक्षम करें",
  "moveUpAndDown": "ऊपर जाएँ / नीचे जाएँ",
  "attributeTable": "विशेषता तालिका में दिखाएँ",
  "url": "विवरण / आइटम विवरण दिखाना / डाउनलोड करें",
  "layerSelectorTitle": "उन लेयरों का चयन करें जो सूची पर दिखाई जाएंगी।"
});