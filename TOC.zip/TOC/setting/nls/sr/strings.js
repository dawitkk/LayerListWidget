define({
  "showLegend": "Prikaži legendu",
  "controlPopupMenuTitle": "Odaberite koje radnje će biti prikazane u kontekst meniju sloja.",
  "zoomto": "Zumiraj na",
  "transparency": "Prozirnost",
  "controlPopup": "Omogući / onemogući iskačuće prozore",
  "moveUpAndDown": "Pomeraj se na gore / na dole",
  "attributeTable": "Prikaži u tabeli atributa",
  "url": "Opis / Prikaži detalje stavke / Preuzmi",
  "layerSelectorTitle": "Odaberite koji slojevi će biti prikazani u listi."
});