define({
  "showLegend": "Rodyti legendą",
  "controlPopupMenuTitle": "Pasirinkti, kurie veiksmai bus rodomi sluoksnių kontekstiniame meniu.",
  "zoomto": "Pritraukti iki",
  "transparency": "Permatomumas",
  "controlPopup": "Įjungti / išjungti iškylančius langus",
  "moveUpAndDown": "Į viršų / į apačią",
  "attributeTable": "Peržiūrėti atributų lentelėje",
  "url": "Aprašymas / Rodyti elemento informaciją / Atsisiųsti",
  "layerSelectorTitle": "Pasirinkti, kurie sluoksniai bus rodomi sąraše."
});