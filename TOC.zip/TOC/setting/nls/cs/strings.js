define({
  "showLegend": "Zobrazit legendu",
  "controlPopupMenuTitle": "Zvolte, které akce se mají zobrazit v kontextové nabídce vrstvy.",
  "zoomto": "Zaostřit",
  "transparency": "Průhlednost",
  "controlPopup": "Povolit/zakázat vyskakovací okna",
  "moveUpAndDown": "Posunout nahoru / dolů",
  "attributeTable": "Zobrazit v atributové tabulce",
  "url": "Popis / Zobrazit podrobnosti položky / Stahování",
  "layerSelectorTitle": "Zvolte, které vrstvy se mají zobrazit v seznamu."
});