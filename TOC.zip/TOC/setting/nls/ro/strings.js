define({
  "showLegend": "Afişare legendă",
  "controlPopupMenuTitle": "Alegeţi ce acţiuni sunt afişate în meniul contextual al stratului tematic.",
  "zoomto": "Transfocare la",
  "transparency": "Transparenţă",
  "controlPopup": "Activare/dezactivare pop-up",
  "moveUpAndDown": "Mutare în sus/Mutare în jos",
  "attributeTable": "Vizualizare în tabelul de atribute",
  "url": "Descriere/Afişare detalii element/Descărcare",
  "layerSelectorTitle": "Alegeţi ce straturi tematice vor fi afişate în listă."
});