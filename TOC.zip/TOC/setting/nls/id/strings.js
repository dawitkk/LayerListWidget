define({
  "showLegend": "Tampilkan legenda",
  "controlPopupMenuTitle": "Pilih tindakan mana yang akan ditampilkan pada menu konteks layer.",
  "zoomto": "Perbesar hingga",
  "transparency": "Transparansi",
  "controlPopup": "Aktifkan / Nonaktifkan pop-up",
  "moveUpAndDown": "Pindahkan ke atas/ke bawah",
  "attributeTable": "Tampilkan dalam Tabel Atribut",
  "url": "Deskripsi / Tampilkan Detail item / Unduhan",
  "layerSelectorTitle": "Pilih layer mana yang akan ditampilkan pada daftar."
});