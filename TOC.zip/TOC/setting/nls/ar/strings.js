define({
  "showLegend": "إظهار وسيلة الإيضاح",
  "controlPopupMenuTitle": "اختر الإجراءات التي ستُعرَض على قائمة سياق الطبقة.",
  "zoomto": "تكبير/تصغير إلى",
  "transparency": "الشفافية",
  "controlPopup": "تمكين/تعطيل العنصر المنبثق",
  "moveUpAndDown": "تحريك لأعلى / تحريك لأسفل",
  "attributeTable": "عرض في جدول البيانات",
  "url": "وصف/عرض تفاصيل العنصر/تنزيل",
  "layerSelectorTitle": "اختر الطبقات التي ستُعرَض على القائمة."
});