define({
  "showLegend": "Mostrar legenda",
  "controlPopupMenuTitle": "Selecione as ações que serão exibidas no menu de contexto da camada.",
  "zoomto": "Efectuar zoom para",
  "transparency": "Transparência",
  "controlPopup": "Ativar / Desativar janela pop-up",
  "moveUpAndDown": "Mover para cima / Mover para baixo",
  "attributeTable": "Visualizar em Tabela de Atributos",
  "url": "Descrição / Mostrar detalhes de item / Transferir",
  "layerSelectorTitle": "Selecione que camadas serão exibidas na lista."
});