define({
  "showLegend": "Pokaż legendę",
  "controlPopupMenuTitle": "Wybierz działania, które będą wyświetlane w menu kontekstowym warstwy.",
  "zoomto": "Powiększ do",
  "transparency": "Przezroczystość",
  "controlPopup": "Włącz/wyłącz okno podręczne",
  "moveUpAndDown": "Przenieś do góry / Przenieś w dół",
  "attributeTable": "Wyświetl w tabeli atrybutów",
  "url": "Opis / Pokaż szczegóły elementu / Pobierz",
  "layerSelectorTitle": "Wybierz warstwy, które zostaną wymienione na liście."
});